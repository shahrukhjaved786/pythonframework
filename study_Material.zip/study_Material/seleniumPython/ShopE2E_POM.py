#Actual Code:

import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from testcase_dir.Baseclass import Baseclass_FixCallL
from testcase_dir.page1_shop import HomePage
from testcase_dir.page2_checkout import CheckOut
from testcase_dir.page3_confirm import ConfirmPurchase


@pytest.mark.usefixtures("invokeBrowser")
class Test_Scenario_DevicePurchase(Baseclass_FixCallL):

    def test_shopE2E(self):

        shopPage_obj = HomePage(self.driver)
        checkout_obj = CheckOut(self.driver)
        confirmpurchase_obj = ConfirmPurchase(self.driver)

        self.driver.get('https://rahulshettyacademy.com/angularpractice/')
        print(f'Page Title: {self.driver.title}')
        print(f'Current URL: {self.driver.current_url}')

        shopPage_obj.shop_click().click()  #POM
        print(f'\nPage Title: {self.driver.title}')
        print(f'Current URL: {self.driver.current_url}\n')

        item_list = checkout_obj.item_lists() #POM
        for value_item in item_list:
            item_name = value_item.find_element(By.XPATH, "div/h4/a").text
            print(item_name)
            if item_name == "iphone X":
                value_item.find_element(By.XPATH, "div[2]/button").click()

        checkout_obj.checkout_initial().click() #POM
        checkout_obj.checkout_final().click() #POM
        confirmpurchase_obj.county_inputbox().send_keys("I") #POM

        wait_EC = WebDriverWait(self.driver, 10)
        wait_EC.until(expected_conditions.presence_of_element_located((By.CSS_SELECTOR, ".suggestions")))

        confirmpurchase_obj.countries_list() #POM

        for value_country in confirmpurchase_obj.countries_list():
            print(value_country.text)

            if value_country.text == 'India':
                value_country.click()
                break

        confirmpurchase_obj.tnc_popup().click() #POM
        time.sleep(1)
        tnc_head = confirmpurchase_obj.tnc_heading().text  #POM
        time.sleep(1)
        tnc_body = confirmpurchase_obj.tnc_bodytext().text  #POM

        print(f"{tnc_head}:\n{tnc_body}")
        confirmpurchase_obj.tnc_close().click()
        confirmpurchase_obj.purchase_click().click() #POM
        success_msg = confirmpurchase_obj.success_text().text #POM

        print(success_msg)
        assert "Success! Thank you!" in success_msg



#Page1 POM

from selenium.webdriver.common.by import By


class HomePage:

    def __init__(self,driver):
        self.driver = driver

    '''
    convert the above web element locator to POM
    # self.driver.find_element(By.XPATH, "//a[contains(@href,'shop')]").click()
    '''

    shop_btn = (By.XPATH, "//a[contains(@href,'shop')]")
    def shop_click(self):
        return self.driver.find_element(*HomePage.shop_btn)



#Page2 POM

from selenium.webdriver.common.by import By


class CheckOut:

    # item_list = self.driver.find_elements(By.XPATH, "//div[@class='card h-100']")
    card_lists = (By.XPATH, "//div[@class='card h-100']")

    # self.driver.find_element(By.PARTIAL_LINK_TEXT, "Checkout").click()
    checkout_btn1 = (By.PARTIAL_LINK_TEXT, "Checkout")

    # self.driver.find_element(By.XPATH, "//button[@class='btn btn-success']").click()
    checkout_btn2 = (By.XPATH, "//button[@class='btn btn-success']")

    def __init__(self, driver):
        self.driver = driver

    def item_lists(self):
        return self.driver.find_elements(*CheckOut.card_lists)

    def checkout_initial(self):
        return self.driver.find_element(*CheckOut.checkout_btn1)

    def checkout_final(self):
        return self.driver.find_element(*CheckOut.checkout_btn2)




#Page3 POM

from selenium.webdriver.common.by import By


class ConfirmPurchase:

    # self.driver.find_element(By.CSS_SELECTOR, "#country").send_keys("I")
    country_inputtext = (By.CSS_SELECTOR, "#country")

    # country_list = self.driver.find_elements(By.XPATH, "//div[@class='suggestions']/ul/li/a")
    country_list =  (By.XPATH, "//div[@class='suggestions']/ul/li/a")

    # self.driver.find_element(By.LINK_TEXT, "term & Conditions").click()
    tnc_hyplink = (By.LINK_TEXT, "term & Conditions")

    # tnc_head = self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/h1").text
    tnc_head = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/h1")

    # tnc_body = self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/p").text
    tnc_body = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/p")

    # self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/button").click()
    tnc_closebtn = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/button")


    # self.driver.find_element(By.XPATH, "//input[@value='Purchase']").click()
    purchase_btn = (By.XPATH, "//input[@value='Purchase']")

    # success_msg = self.driver.find_element(By.CLASS_NAME, "alert-success").text
    success_msg = (By.CLASS_NAME, "alert-success")

    def __init__(self,driver):
        self.driver = driver

    def county_inputbox(self):
        return self.driver.find_element(*ConfirmPurchase.country_inputtext)

    def countries_list(self):
        return self.driver.find_elements(*ConfirmPurchase.country_list)

    def tnc_popup(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_hyplink)

    def tnc_heading(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_head)

    def tnc_bodytext(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_body)

    def tnc_close(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_closebtn)

    def purchase_click(self):
        return self.driver.find_element(*ConfirmPurchase.purchase_btn)

    def success_text(self):
        return self.driver.find_element(*ConfirmPurchase.success_msg)






