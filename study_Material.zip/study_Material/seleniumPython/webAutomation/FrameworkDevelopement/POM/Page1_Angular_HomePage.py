from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


class AngularHP_FormSubmission:

    # driver.find_element(By.NAME, "name").send_keys('John Wick_01')
    # driver.find_element(By.XPATH, "//input[@name='email']").send_keys('jwick099@xyz.com')
    # driver.find_element(By.CSS_SELECTOR, "input[type='password']").send_keys('dummypass@1')
    # Select(driver.find_element(By.CSS_SELECTOR, "#exampleFormControlSelect1"))
    # driver.find_element(By.CSS_SELECTOR, "#exampleCheck1").click()
    # driver.find_element(By.ID, "inlineRadio1").click()
    # driver.find_element(By.CSS_SELECTOR, "#inlineRadio2").click()
    # driver.find_element(By.XPATH, "//h4/input").send_keys('Two Way Text')
    # driver.find_element(By.XPATH, "//input[@type='submit']").click()
    # driver.find_element(By.CSS_SELECTOR, ".alert-success").text
    # driver.find_element(By.LINK_TEXT, "Shop").click()


    nameBox = (By.NAME, "name")
    emailBox = (By.XPATH, "//input[@name='email']")
    passwordBox = (By.CSS_SELECTOR, "input[type='password']")
    dropDown = (By.CSS_SELECTOR, "#exampleFormControlSelect1") #Using with generic DD select from baseclass
    checkBox = (By.CSS_SELECTOR, "#exampleCheck1")
    student_Radio = (By.ID, "inlineRadio1")
    employed_Radio = (By.CSS_SELECTOR, "#inlineRadio2")
    twoWayInputBox = (By.XPATH, "//h4/input")
    submitBtn = (By.XPATH, "//input[@type='submit']")
    successMsg = (By.CSS_SELECTOR,".alert-success")
    shopBtn = (By.LINK_TEXT, "Shop")

    def __init__(self, driver):
        self.driver = driver

    def shopButton(self):
        return self.driver.find_element(*AngularHP_FormSubmission.shopBtn)

    def nameInput(self):
        return self.driver.find_element(*AngularHP_FormSubmission.nameBox)

    def emailInput(self):
        return self.driver.find_element(*AngularHP_FormSubmission.emailBox)

    def passwordInput(self):
        return self.driver.find_element(*AngularHP_FormSubmission.passwordBox)

    def genderDownDown(self):
        return self.driver.find_element(*AngularHP_FormSubmission.dropDown)

    def iceCreamCheckBok(self):
        return self.driver.find_element(*AngularHP_FormSubmission.checkBox)

    def studentRadioBtn(self):
        return self.driver.find_element(*AngularHP_FormSubmission.student_Radio)

    def employedRadioBtn(self):
        return self.driver.find_element(*AngularHP_FormSubmission.employed_Radio)

    def twoWayInput(self):
        return self.driver.find_element(*AngularHP_FormSubmission.twoWayInputBox)

    def submitButton(self):
        return self.driver.find_element(*AngularHP_FormSubmission.submitBtn)

    def successMessage(self):
        return self.driver.find_element(*AngularHP_FormSubmission.successMsg)







