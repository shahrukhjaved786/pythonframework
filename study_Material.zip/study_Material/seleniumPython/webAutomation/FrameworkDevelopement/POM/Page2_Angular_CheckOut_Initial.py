from selenium.webdriver.common.by import By


class Angular_Checkout_FirstPage:

    header1 = (By.XPATH, "//div/h1")
    item_cards = (By.XPATH, "//div[@class='card h-100']")
    # checkBtn_first = (By.PARTIAL_LINK_TEXT, " Checkout ( 0 ) ")
    checkBtn_first = (By.XPATH, "//li[@class='nav-item active']/a")

    def __init__(self, driver):
        self.driver = driver

    def pageHeading(self):
        return self.driver.find_element(*Angular_Checkout_FirstPage.header1)

    def item_Cards_List(self):
        return self.driver.find_elements(*Angular_Checkout_FirstPage.item_cards)

    def checkOut_Btn_Count(self):
        return self.driver.find_element(*Angular_Checkout_FirstPage.checkBtn_first)