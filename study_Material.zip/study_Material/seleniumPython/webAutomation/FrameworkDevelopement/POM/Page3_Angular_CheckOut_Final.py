from selenium.webdriver.common.by import By


class Angular_CheckOutPage_Final:

    checkoutBtn = (By.CSS_SELECTOR, ".btn-success")

    def __init__(self, driver):
        self.driver = driver

    def checkOutFinal(self):
        return self.driver.find_element(*Angular_CheckOutPage_Final.checkoutBtn)