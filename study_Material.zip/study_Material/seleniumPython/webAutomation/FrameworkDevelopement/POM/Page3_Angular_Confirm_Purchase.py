from selenium.webdriver.common.by import By


class Angular_Confirm_Purchase:

    countryBox = (By.CSS_SELECTOR, "#country")
    all_countries = (By.XPATH, "//div[@class='suggestions']/ul/li/a")
    tnc_hypLink = (By.LINK_TEXT, "term & Conditions")
    tcn_head = (By.XPATH, "//div/h1")
    tnc_statement = (By.XPATH, "//ngx-smart-modal/div[2]/p")
    tnc_popup_CloseBtn = (By.XPATH, "//ngx-smart-modal/div[2]/button[1]")
    purchaseBtn = (By.XPATH, "//input[@type='submit']")
    successBanner = (By.CSS_SELECTOR, ".alert-success")
    dismiss_successBanner = (By.XPATH, "//div[@class='alert alert-success alert-dismissible']/a")

    def __init__(self, driver):
        self.driver = driver

    def countryInput(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.countryBox)

    def country_list(self):
        return self.driver.find_elements(*Angular_Confirm_Purchase.all_countries)

    def tncAccept(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.tnc_hypLink)

    def tncHeading(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.tcn_head)

    def tncBody(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.tnc_statement)

    def tncPopUpClose(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.tnc_popup_CloseBtn)

    def purchaseButton(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.purchaseBtn)

    def successMsg(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.successBanner)

    def dismissSuccessMsg(self):
        return self.driver.find_element(*Angular_Confirm_Purchase.dismiss_successBanner)



