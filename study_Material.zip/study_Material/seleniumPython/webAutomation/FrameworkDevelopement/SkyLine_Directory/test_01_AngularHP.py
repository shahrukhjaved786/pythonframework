import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

from FrameworkDevelopement.POM.Page1_Angular_HomePage import AngularHP_FormSubmission
from FrameworkDevelopement.Utilities.BaseClass import BaseClass_util
from FrameworkDevelopement.Utilities.Base_URL import applicationURL


class Test_AngularHomePage(BaseClass_util):

#Verify the Title of the web page
    def test_PageTitle(self, invokeBrowser):

        mylogger = self.LogGenerator()
        self.driver.get(applicationURL.angularHomePage)

        mylogger.info(f"Web Page Title: {self.driver.title}")
        assert self.driver.title == "ProtoCommerce" , "Page Title Did Not Match As Expected"

#Verify the current url after visiting to web page
    def test_CurrentURL(self):
        mylogger = self.LogGenerator()
        self.driver.get(applicationURL.angularHomePage)

        assert self.driver.current_url == applicationURL.angularHomePage
        mylogger.info(f"Current URL : {self.driver.current_url}")

#Verify the functionality of Name, Email & Password input feild

    def test_NameEmailPasswordInput(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)

        self.driver.get(applicationURL.angularHomePage)
        mylogger.info("Opening Angular Homepage")

        homepage_obj.nameInput().send_keys('John Wick_01')
        mylogger.info(f"Name Input: {homepage_obj.nameInput().get_attribute('value')}")

        homepage_obj.emailInput().send_keys('jwick099@xyz.com')
        mylogger.info(f"Email Input: {homepage_obj.emailInput().get_attribute('value')}")

        homepage_obj.passwordInput().send_keys('dummypass@1')
        mylogger.info(f"Password Input: {homepage_obj.passwordInput().get_attribute('value')}")

#Verify the functionality of gender dropdown
    def test_GenderDropDown(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)

        self.driver.get(applicationURL.angularHomePage)

        # Generic Method To Select Any DropDown From Base Class -- self.selectDropDown_VisibleTest()
        self.selectDropDown_VisibleTest(locator_Method=homepage_obj.genderDownDown(),text='Female')
        mylogger.info(f"Dropdown Selected Value: {Select(homepage_obj.genderDownDown()).first_selected_option.get_attribute('value')}")

#Verify the functionality of ice cream check box
    def test_IceCreamCheckBox(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)

        self.driver.get(applicationURL.angularHomePage)

        homepage_obj.iceCreamCheckBok().click()
        mylogger.info(f"CheckBox Selected: {homepage_obj.iceCreamCheckBok().is_selected()}")

#Verify Radio Selection based on user choice
    def test_Radiobutton(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)

        self.driver.get(applicationURL.angularHomePage)

        # userchoice = "null"
        # userchoice = 'STUDENT'
        userchoice = "EMPLOYED"

        if userchoice.lower() == 'student':
            homepage_obj.studentRadioBtn().click()
            mylogger.info(f"Student Radio Selection: {homepage_obj.studentRadioBtn().is_selected()} ")

        elif userchoice.lower() == 'employed':
            homepage_obj.employedRadioBtn().click()
            mylogger.info(f"Employed Radio Selection: {homepage_obj.employedRadioBtn().is_selected()}")

        else:
            mylogger.info('Invalid User Choice, executing else block')

#Verify the functionality of two-way binding input box

    def test_TwoWayBindingInput(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)
        self.driver.get("https://rahulshettyacademy.com/angularpractice/")

        homepage_obj.twoWayInput().send_keys('Second Text For Binding Box')
        mylogger.info(f"Text In Two Way Binding Box: {homepage_obj.twoWayInput().get_attribute('value')}")

    def test_SubmitBtn(self):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)

        homepage_obj.submitButton().click()
        assert "Success" in homepage_obj.successMessage().text
        mylogger.info(f"Submission Alert Message After Submit Click: {homepage_obj.successMessage().text}")






