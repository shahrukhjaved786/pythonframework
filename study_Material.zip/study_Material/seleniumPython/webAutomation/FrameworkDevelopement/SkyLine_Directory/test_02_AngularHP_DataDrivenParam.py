import pytest
from FrameworkDevelopement.DataSets_DDP.DS_AngularHP import AngularHPDataSet
from FrameworkDevelopement.POM.Page1_Angular_HomePage import AngularHP_FormSubmission
from FrameworkDevelopement.Utilities.BaseClass import BaseClass_util
from FrameworkDevelopement.Utilities.Base_URL import applicationURL


@pytest.mark.usefixtures("formSubmissionDataSet")
class Test_AngularHomePage_DataDrivenParam(BaseClass_util):

    def test_FormSubmission(self, invokeBrowser, formSubmissionDataSet):
        homepage_obj = AngularHP_FormSubmission(self.driver)
        mylogger = self.LogGenerator()

        self.driver.get(applicationURL.angularHomePage)

        print(homepage_obj.nameInput().get_attribute('value'))
        print(homepage_obj.emailInput().get_attribute('value'))
        print(homepage_obj.passwordInput().get_attribute('value'))

        #Data set passed in Dictionary format
        homepage_obj.nameInput().send_keys(formSubmissionDataSet['name'])
        homepage_obj.emailInput().send_keys(formSubmissionDataSet['email'])
        homepage_obj.passwordInput().send_keys(formSubmissionDataSet['password'])

        # Data set passed in Tuple format
        # homepage_obj.nameInput().send_keys(formSubmissionDataSet[0])
        # homepage_obj.emailInput().send_keys(formSubmissionDataSet[1])
        # homepage_obj.passwordInput().send_keys(formSubmissionDataSet[2])

        mylogger.info(homepage_obj.nameInput().get_attribute('value'))
        mylogger.info(homepage_obj.emailInput().get_attribute('value'))
        mylogger.info(homepage_obj.passwordInput().get_attribute('value'))

        self.driver.refresh()


'''
Fixture For Tuple Format Data Set 
'''
# @pytest.fixture(params=[('Jim Alpha', 'J.aplha@xyz.com', 'jim@pass123'),
#                               ('Mic Beta', 'm.beta@abc.com', 'mic@pass123'),
#                               ('Ross Catiline', 'cat.cyphe@qwert.org', 'ross@pass123')])
# def formSubmissionDataSet(request):
#     return request.param


'''
Fixture For Dictionary Format Data Set 
'''

@pytest.fixture(params=[{'name':"Apple Man", 'email':"awesomeapple@apple.com", 'password':"pass@apple"},
                        {'name':"Biscuit Boy", 'email':"blisfullbiscuits@bks.com", 'password':"pass@biks"},
                        {'name':"Chilly Chocolate", 'email':"chocochill@xyz.com", 'password':"pass@bchikls"}])
def formSubmissionDataSet(request):
    return request.param

'''
Calling Data Set from dedicated class [Tuple Format ]
'''
#
# @pytest.fixture(params=AngularHPDataSet.data_NameEmailPassword)
# def formSubmissionDataSet(request):
#     return request.param


'''
FIX REQUIRED:

Why Redundant data in logs?
'''