import time
import pytest
from FrameworkDevelopement.POM.Page1_Angular_HomePage import AngularHP_FormSubmission
from FrameworkDevelopement.Utilities.BaseClass import BaseClass_util
from FrameworkDevelopement.Utilities.Base_URL import applicationURL


@pytest.mark.usefixtures("userInfoFormFill")
class Test_AngularHP_FormSubmission(BaseClass_util):

    def test_FormSubmission(self, invokeBrowser, userInfoFormFill):

        homepage_obj = AngularHP_FormSubmission(self.driver)
        mylogger = self.LogGenerator()

        self.driver.get(applicationURL.angularHomePage)
        mylogger.info(f'Opening {self.driver.current_url}')

        homepage_obj.nameInput().send_keys(userInfoFormFill['Name'])
        homepage_obj.emailInput().send_keys(userInfoFormFill['Email'])
        homepage_obj.passwordInput().send_keys(userInfoFormFill['Password'])
        homepage_obj.submitButton().click()
        assert 'Success' in homepage_obj.successMessage().text
        time.sleep(3)

        mylogger.info(homepage_obj.nameInput().get_attribute('value'))
        mylogger.info(homepage_obj.emailInput().get_attribute('value'))
        mylogger.info(homepage_obj.passwordInput().get_attribute('value'))


@pytest.fixture(params=BaseClass_util.readExcelData('/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/oPyXL/BookTestOPE.xlsx',
                                                    'FormSubmission'))
def userInfoFormFill(request):
    return request.param























