from selenium.webdriver.common.by import By

from FrameworkDevelopement.POM.Page1_Angular_HomePage import AngularHP_FormSubmission
from FrameworkDevelopement.POM.Page2_Angular_CheckOut_Initial import Angular_Checkout_FirstPage
from FrameworkDevelopement.POM.Page3_Angular_CheckOut_Final import Angular_CheckOutPage_Final
from FrameworkDevelopement.POM.Page3_Angular_Confirm_Purchase import Angular_Confirm_Purchase
from FrameworkDevelopement.Utilities.BaseClass import BaseClass_util
from FrameworkDevelopement.Utilities.Base_URL import applicationURL


class Test_DevicePurchase(BaseClass_util):

    def test_Purchase(self, invokeBrowser):
        mylogger = self.LogGenerator()
        homepage_obj = AngularHP_FormSubmission(self.driver)
        checkoutPage_First_obj = Angular_Checkout_FirstPage(self.driver)
        checkOutPage_Final_obj = Angular_CheckOutPage_Final(self.driver)
        confirmPurchase_obj = Angular_Confirm_Purchase(self.driver)

        mylogger.info("Opening webpage")
        self.driver.get(applicationURL.angularHomePage)
        homepage_obj.shopButton().click()
        mylogger.info("Clicked on Shop button")

        assert "Shop Name" == checkoutPage_First_obj.pageHeading().text , "Checkout page title error"
        mylogger.info(f"Check Out First Page Heading : {checkoutPage_First_obj.pageHeading().text}")

        assert '0' in checkoutPage_First_obj.checkOut_Btn_Count().text , "Default checkout count mismatch"
        mylogger.info(f"Default Check Out Item Count : {checkoutPage_First_obj.checkOut_Btn_Count().text}")

        mylogger.info(f"Number of Available Items: {len(checkoutPage_First_obj.item_Cards_List())}")
        for value_item in checkoutPage_First_obj.item_Cards_List():
            item_title = value_item.find_element(By.XPATH, "div[1]/h4/a").text
            mylogger.info(f"Available Items: {item_title}")

            '''
            Modify Logic to get all available items in logs  -- before control flow interruption
            Without affecting memory efficiency & time complexity 
            '''

            if item_title == "Nokia Edge":
                value_item.find_element(By.XPATH, "div[2]/button").click()
                mylogger.info(f"Added Item To Card: {item_title}")
                break
            else:
                pass

        assert '1' in checkoutPage_First_obj.checkOut_Btn_Count().text , "Checkout item count value mismatch"
        mylogger.info(f"Item Count After Selection : {checkoutPage_First_obj.checkOut_Btn_Count().text}")

        checkoutPage_First_obj.checkOut_Btn_Count().click()
        mylogger.info("Proceed to checkout final page")

        checkOutPage_Final_obj.checkOutFinal().click()
        mylogger.info("Checkout done, Next Page is TnC")

        confirmPurchase_obj.countryInput().send_keys('in')
        self.explicit_Wait(locatorMethod=By.CSS_SELECTOR, webElement=".suggestions")

        for value_country in confirmPurchase_obj.country_list():
            if value_country.text == 'India':
                value_country.click()
                break

        mylogger.info(f"Selected Country : {confirmPurchase_obj.countryInput().get_attribute('value')}")

        confirmPurchase_obj.tncAccept().click()

        self.explicit_Wait(locatorMethod=By.XPATH, webElement="//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']")

        mylogger.info(f"T&C Heading: {confirmPurchase_obj.tncHeading().text}")
        mylogger.info(f"T&C Body : {confirmPurchase_obj.tncBody().text}")
        confirmPurchase_obj.tncPopUpClose().click()
        assert not confirmPurchase_obj.tncAccept().is_selected() , "Checkbox not selected"
        mylogger.info(f'T&C Check Box Clicked: {confirmPurchase_obj.tncAccept().is_selected()}')

        confirmPurchase_obj.purchaseButton().click()
        mylogger.info("Purchase button clicked successfully")
        success_message = confirmPurchase_obj.successMsg().text
        assert "Success!" and "Thank you" in success_message , "Error in success message"
        mylogger.info(f"Order Placed, Final Message: {success_message}")
        confirmPurchase_obj.dismissSuccessMsg().click()
        mylogger.info(f"Dismissed Success Banner")