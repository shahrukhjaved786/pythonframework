import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service



@pytest.fixture(scope="class")
def invokeBrowser(request):
    start_time = time.time()

    service_obj = Service()
    customOptions = EdgeOptions()
    customOptions.add_argument('inprivate')
    customOptions.add_argument('start-maximized')

    driver = webdriver.Edge(service=service_obj,options=customOptions)

    # To Link the driver object defined in fixture with method defined inside class in testcase
    request.cls.driver = driver




    yield
    driver.close()

    end_time = time.time()
    execution_duration = end_time - start_time
    start_Ctime = time.ctime(start_time)
    end_Ctime = time.ctime(end_time)
    print(f"\nStart Time: {start_Ctime}\nEnd Time: {end_Ctime}\nElapsed Time: {execution_duration}")