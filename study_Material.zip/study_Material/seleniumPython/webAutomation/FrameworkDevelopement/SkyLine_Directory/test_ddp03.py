import openpyxl


class Test_DDP:
    @staticmethod
    def getUserInfo(testcase_id):

        data_dict = {}
        userDataList = []

        book = openpyxl.load_workbook(
            "/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/oPyXL/BookTestOPE.xlsx")
        sheet = book.active

        for value_i in range(1, sheet.max_row + 1):
            if testcase_id in sheet.cell(row=value_i, column=1).value:
                for value_j in range(1, sheet.max_column + 1):
                    data_dict[sheet.cell(row=1, column=value_j).value] = sheet.cell(row=value_i, column=value_j).value
                    userDataList.append(data_dict.copy())

        # return userDataList
        print(userDataList)

#
# import time
# import pytest
# from FrameworkDevelopement.POM.Page1_Angular_HomePage import AngularHP_FormSubmission
# from FrameworkDevelopement.Utilities.BaseClass import BaseClass_util
# from FrameworkDevelopement.Utilities.Base_URL import applicationURL
#
# @pytest.mark.usefixtures('testuserdata')
# class Test_AngularHPFS(BaseClass_util):
#
#     def test_formsubmission(self, invokeBrowser,testuserdata):
#         homepage_obj = AngularHP_FormSubmission(self.driver)
#
#         self.driver.get(applicationURL.angularHomePage)
#
#         homepage_obj.nameInput().send_keys(testuserdata['Name'])
#         homepage_obj.emailInput().send_keys(testuserdata['Email'])
#         homepage_obj.passwordInput().send_keys(testuserdata['Password'])
#         homepage_obj.submitButton().click()
#         time.sleep(5)

#
# @pytest.fixture(params=[{'Uname': "Mokshi",
#                          'Email': "mok@abc.com",
#                          'Password': "pass@12345"}])
# def testuserdata(request):
#     return request.param


#
# @pytest.fixture(params=Test_DDP.getUserInfo('FormSubmission'))
# def testuserdata(request):
#     return request.param









Test_DDP.getUserInfo('FormSubmission')