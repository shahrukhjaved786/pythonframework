
class AngularHPDataSet:
    data_NameEmailPassword = [('Jim Alpha', 'J.aplha@xyz.com', 'jim@pass123'),
                              ('Mic Beta', 'm.beta@abc.com', 'mic@pass123'),
                              ('Ross Catiline', 'cat.cyphe@qwert.org', 'ross@pass123')]