
class applicationURL:

    angularHomePage = "https://rahulshettyacademy.com/angularpractice/"

