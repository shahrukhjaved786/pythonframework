import inspect
import logging
import openpyxl
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait


@pytest.mark.usefixtures("invokeBrowser")
class BaseClass_util: #Parent class that stores all generic items to inherit its properties into chile class

    @staticmethod
    def readExcelData(excelFilePath, testCaseId):
        dataSetList = []
        dataDict = {}

        book = openpyxl.load_workbook(excelFilePath)
        sheet = book.active

        for value_i in range(1, sheet.max_row + 1):
            if testCaseId in sheet.cell(row=value_i, column=1).value:
                for value_j in range(1, sheet.max_column + 1):
                    dataDict[sheet.cell(row=1, column=value_j).value] = sheet.cell(row=value_i, column=value_j).value

                dataSetList.append(dataDict.copy())

        return dataSetList

    def LogGenerator(self):
        loggerMethodName = inspect.stack()[1][3]   #This INSPECT helps to print exact method name is logs
        # logger_obj = logging.getLogger(__name__) #__name__ print FileName in Logs

        logger_obj = logging.getLogger(loggerMethodName)

        filehandler_obj = logging.FileHandler('/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/FrameworkDevelopement/LogFiles/LogFile.log')

        default_logging_format = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
        filehandler_obj.setFormatter(default_logging_format)

        logger_obj.addHandler(filehandler_obj)
        logger_obj.setLevel(logging.DEBUG)

        return logger_obj

    def explicit_Wait(self,locatorMethod,webElement):
        wait_exp = WebDriverWait(self.driver, 30)
        wait_exp.until(expected_conditions.presence_of_element_located((locatorMethod, webElement)))

    def selectDropDown_VisibleTest(self,locator_Method, text):
        dropdown_select = Select(locator_Method)
        dropdown_select.select_by_visible_text(text=text)







'''
Steps:

1. import logging
2. use logging.getLogger() method and pass the __name__ [to grab the exact pytest file name]
3. define the logging messages such as [ logger_obj.critical('Critical Error') ]
4. Give information about in which file logs has to be printed by using addHandler & FileHandler method
    filehandler_obj = logging.FileHandler('pytest_logfile.txt') [pass the default logs path]
    logger_obj = logging.addHandler(filehandler_obj)

5. Now give the information in which format to print logs
    default_log_format = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
    fileHandler.setFormatter(default_log_format)

6. At Last set the level from which level onwards logs has to be printed
    logger_obj.setLevel(logging.INFO)


'''

