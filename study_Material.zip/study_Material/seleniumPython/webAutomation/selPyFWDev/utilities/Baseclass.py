import inspect
import logging
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

@pytest.mark.usefixtures('invokeBrowser')
class Baseclass:

    def explicitWaitElementPresence(self,element_id):
        wait_EC = WebDriverWait(self.driver, 10)
        wait_EC.until(expected_conditions.presence_of_element_located((By.CSS_SELECTOR, element_id)))

    def LogCollector(self):
        loggerMethodName = inspect.stack()[1][3]
        logger_obj = logging.getLogger(loggerMethodName)

        fileHandler_obj = logging.FileHandler('/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/selPyFWDev/logFiles/LogFile.log')

        default_logging_syntax = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
        fileHandler_obj.setFormatter(default_logging_syntax)

        logger_obj.addHandler(fileHandler_obj)

        logger_obj.setLevel(logging.DEBUG)

        return logger_obj

