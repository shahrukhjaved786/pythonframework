import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service


# userEmail = input('Enter Email Address: ')
# userPassword = input('Enter Password: ')

userEmail = 'hcl.regtestQ014Meta01@arvrqa.net'
userPassword = 'IloveOculus1'


service_obj = Service()
customOptions = EdgeOptions()
# customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
# customOptions.add_argument('headless')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(5)
action_chain = ActionChains(driver=driver)

driver.get("https://auth.meta.com")
time.sleep(2)

driver.find_element(By.XPATH, "//div[text()='हिन्दी']").click()
language_list = driver.find_elements(By.XPATH, "//div[@role='menuitem']/div/div/div/div/div")
for value_lang in language_list:
    if value_lang.text == "English (UK)":
        value_lang.click()
        break
driver.refresh()

driver.find_element(By.XPATH, "//span[text()='Continue with email address']").click()
# driver.find_element(By.XPATH, "//span[text()='ईमेल के साथ जारी रखें']").click()
time.sleep(2)
driver.find_element(By.XPATH, "//input[@inputmode='email']").send_keys(userEmail)
time.sleep(2)
action_chain.move_by_offset(690,400).click().perform()
time.sleep(5)


# driver.find_element(By.XPATH, "//span[text()='Enter password instead']")

action_chain.move_by_offset(690,300).click().perform()
time.sleep(5)
driver.find_element(By.CSS_SELECTOR, "input[type='password']").send_keys(userPassword)
time.sleep(2)
# driver.find_element(By.XPATH, "//span[text()='Log in']").click()

action_chain.move_by_offset(690,400).click().perform()
time.sleep(2)

driver.get('https://meta.com/device')
time.sleep(5)

