class HomePageData:

    formFillDataSet1 = [{'email': "testing123@mail.com", 'password': "pass@123", 'name': "Ross Miller"},
                            {'email': "example12@xyz.com", 'password': 'abc@123', 'name': "Miranda"}]