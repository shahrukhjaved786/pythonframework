from selenium.webdriver.common.by import By

from testcase_dir.page3_confirm import ConfirmPurchase


class CheckOut:

    # item_list = self.driver.find_elements(By.XPATH, "//div[@class='card h-100']")
    card_lists = (By.XPATH, "//div[@class='card h-100']")
    # self.driver.find_element(By.PARTIAL_LINK_TEXT, "Checkout").click()
    checkout_btn1 = (By.PARTIAL_LINK_TEXT, "Checkout")
    # self.driver.find_element(By.XPATH, "//button[@class='btn btn-success']").click()
    checkout_btn2 = (By.XPATH, "//button[@class='btn btn-success']")

    def __init__(self, driver):
        self.driver = driver

    def item_lists(self):
        return self.driver.find_elements(*CheckOut.card_lists)

    def checkout_initial(self):
        return self.driver.find_element(*CheckOut.checkout_btn1)

    def checkout_final(self):
        self.driver.find_element(*CheckOut.checkout_btn2).click()
        confirmpurchase_obj = ConfirmPurchase(self.driver)
        return confirmpurchase_obj




