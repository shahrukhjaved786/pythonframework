from selenium.webdriver.common.by import By


class FormInputs:
    # self.driver.find_element(By.NAME, 'email').send_keys('testemail@xyz.com')
    emailBox = (By.NAME, 'email')
    # self.driver.find_element(By.ID, 'exampleInputPassword1').send_keys('12345')
    passwordBox = (By.ID, 'exampleInputPassword1')
    # self.driver.find_element(By.XPATH, "//input[@type='checkbox']").click()
    checkbox = (By.XPATH, "//input[@type='checkbox']")
    # gender_DD = self.driver.find_element(By.CSS_SELECTOR, '#exampleFormControlSelect1')
    gender_dropdown = (By.CSS_SELECTOR, '#exampleFormControlSelect1')
    # self.driver.find_element(By.CSS_SELECTOR, "input[name='name']").send_keys('Testing123')
    nameBox =  (By.CSS_SELECTOR, "input[name='name']")
    # self.driver.find_element(By.XPATH, "(//input[@type='text'])[3]").clear()
    clearNameBox = (By.XPATH, "(//input[@type='text'])[3]")
    # self.driver.find_element(By.CSS_SELECTOR, "#inlineRadio1").click()
    radioSelect = (By.CSS_SELECTOR, "#inlineRadio1")
    # self.driver.find_element(By.XPATH, "//input[@value='Submit']").click()
    submitBtn = (By.XPATH, "//input[@value='Submit']")
    # success_banner = self.driver.find_element(By.CSS_SELECTOR, ".alert-success").text
    alertMsg = (By.CSS_SELECTOR, ".alert-success")


    def __init__(self,driver):
        self.driver = driver

    def email_input(self, email):
        return self.driver.find_element(*FormInputs.emailBox).send_keys(email)

    def pass_input(self, password):
        return self.driver.find_element(*FormInputs.passwordBox).send_keys(password)

    def checkboxSelect(self):
        return self.driver.find_element(*FormInputs.checkbox).click()

    def genderRadio(self):
        return self.driver.find_element(*FormInputs.gender_dropdown)

    def name_input(self,uname):
        return self.driver.find_element(*FormInputs.nameBox).send_keys(uname)

    def name_inputClear(self):
        return self.driver.find_element(*FormInputs.clearNameBox).clear()

    def select_radio(self):
        return self.driver.find_element(*FormInputs.radioSelect).click()

    def submitBtn_Click(self):
        return self.driver.find_element(*FormInputs.submitBtn).click()

    def successAlertMsg(self):
        return self.driver.find_element(*FormInputs.alertMsg).text