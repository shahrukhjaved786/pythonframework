

class TestOne(
    BaseClass):  # Inheritance concept where parent class(BaseClass) is inherited in base class. Parent class(BaseClass) will call setup fixture using @pytest.mark.usefixtures("setup") under conftest
    def test_e2e(self):
        log = self.test_logger()
        homePage = HomePage(
            self.driver)  # Object of HomePage class is created and driver is shared with HomePage class constructor, refer homePage.py file
        checkoutPage = homePage.shopItems()  # shopItems method return the object of class CheckoutPage
        # homePage.shopItems().click()        # shopItems method from class HomePage is called with the help of object homePage
        cardTitle = checkoutPage.getCardTitles()


################################################################################

from selenium.webdriver.common.by import By

# Class file for Home page object repo
from pageObjects.checkoutPage import CheckoutPage


class HomePage:
    shop = (By.CSS_SELECTOR, "a[href*='shop']")  # shop link locator is stored in shop variable
    name = (By.XPATH, "//label[text()='Name']/..//input")
    email = (By.NAME, "email")
    password = (By.ID, "exampleInputPassword1")
    checkbox = (By.ID, "exampleCheck1")
    gender = (By.ID, "exampleFormControlSelect1")
    submit = (By.XPATH, "//input[@value='Submit']")
    alert = (By.CLASS_NAME, "alert-success")

    def __init__(self, driver):  # Constructor which has driver
        self.driver = driver

    def shopItems(self):  # Method which define find_element for shop variable
        # * is used to Deserialize find_element
        # HomePage.shop: class variable 'shop' is called by className.variable
        self.driver.find_element(*HomePage.shop).click()
        checkoutPage = CheckoutPage(self.driver)
        return checkoutPage


################################################################################

from selenium.webdriver.common.by import By

from pageObjects.confirmPage import ConfirmPage


class CheckoutPage:
    cardTitle = (By.XPATH, "//div[@class='card h-100']")
    cardText = (By.XPATH, "div/h4/a")
    checkoutbutton = (By.XPATH, "//div[@id='navbarResponsive']//a")
    confirmcheckoutbutton = (By.CSS_SELECTOR, "button[class='btn btn-success']")

    def __init__(self, driver):
        self.driver = driver

    def getCardTitles(self):
        return self.driver.find_elements(*CheckoutPage.cardTitle)
