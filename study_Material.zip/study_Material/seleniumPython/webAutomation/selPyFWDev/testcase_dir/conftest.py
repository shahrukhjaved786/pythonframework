import time
import pytest
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as Service_ch
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service as Service_ed
from selenium import webdriver
from selenium.webdriver.safari.options import Options as SafariOptions
from selenium.webdriver.safari.service import Service as Service_saf


def pytest_addoption(parser):
    parser.addoption(
        "--browserName", action="store", default="edge", help="Browser Options: edge or safari"
    )


@pytest.fixture(scope='class')
def invokeBrowser(request):
    start_time = time.time()
    selected_browser = request.config.getoption("browserName")

    if selected_browser == "edge":
        service_ed_obj = Service_ed()
        customOptions_ed = EdgeOptions()
        customOptions_ed.add_argument('inprivate')
        customOptions_ed.add_argument('start-maximized')
        driver = webdriver.Edge(service=service_ed_obj, options=customOptions_ed)

    elif selected_browser == "safari":
        service_saf_obj = Service_saf()
        customOptions_saf = SafariOptions()
        customOptions_saf.add_argument('inprivate')
        customOptions_saf.add_argument('start-maximized')

        driver = webdriver.Safari(service=service_saf_obj,options=customOptions_saf)

    elif selected_browser == "chrome":
        service_ch_obj = Service_ch()
        customOptions_ch = ChromeOptions()
        customOptions_ch.add_argument('incognito')
        customOptions_ch.add_argument('start-maximized')

        driver = webdriver.Chrome(service=service_ch_obj,options=customOptions_ch)

    request.cls.driver = driver

    yield
    end_time = time.time()
    execution_time = end_time - start_time

    start_time = time.ctime(start_time)
    end_time = time.ctime(end_time)
    print(f"\nStart Time: {start_time}\nEnd Time: {end_time}\nTotal Execution Duration: {execution_time}")