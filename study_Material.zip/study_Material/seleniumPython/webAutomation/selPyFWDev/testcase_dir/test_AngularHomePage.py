import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from testcase_dir.page1_Form import FormInputs
from utilities.Baseclass import Baseclass_FixCallL


class TestHomePageAngular(Baseclass_FixCallL):

    def test_FormSubmission(self):

        homepage = FormInputs(self.driver)

        self.driver.get('https://rahulshettyacademy.com/angularpractice/')
        print(f'Title of the webpage is: {self.driver.title}')
        # self.driver.find_element(By.NAME, 'email').send_keys('testemail@xyz.com')
        homepage.email_input('testemail@xyz.com')
        # self.driver.find_element(By.ID, 'exampleInputPassword1').send_keys('12345')
        homepage.pass_input('pass@12345')
        # self.driver.find_element(By.XPATH, "//input[@type='checkbox']").click()
        homepage.checkboxSelect()
        # gender_DD = self.driver.find_element(By.CSS_SELECTOR, '#exampleFormControlSelect1')
        gender_DD = homepage.genderRadio()
        dropdown = Select(gender_DD)
        dropdown.select_by_visible_text('Female')
        dropdown.select_by_index(0)
        # self.driver.find_element(By.CSS_SELECTOR, "input[name='name']").send_keys('Testing123')
        homepage.name_input('Testing123')
        # self.driver.find_element(By.XPATH, "(//input[@type='text'])[3]").clear()
        homepage.name_inputClear()
        # self.driver.find_element(By.CSS_SELECTOR, "#inlineRadio1").click()
        homepage.select_radio()
        # self.driver.find_element(By.XPATH, "//input[@value='Submit']").click()
        homepage.submitBtn_Click()
        # success_banner = self.driver.find_element(By.CSS_SELECTOR,".alert-success").text
        homepage.successAlertMsg()
        print(homepage.successAlertMsg())

        self.driver.find_element(By.XPATH, "(//input[@type='text'])[3]").send_keys(homepage.successAlertMsg())
        time.sleep(2)

        assert 'Success!' in homepage.successAlertMsg()









