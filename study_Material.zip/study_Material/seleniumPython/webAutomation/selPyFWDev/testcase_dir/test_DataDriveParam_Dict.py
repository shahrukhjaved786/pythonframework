import time

import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

from DateSet.data_AngularHomePage import HomePageData
from testcase_dir.page1_Form import FormInputs
from utilities.Baseclass import Baseclass_FixCallL


class TestHomePageAngular(Baseclass_FixCallL):

    def test_FormSubmission(self,formFillDataSet):

        homepage = FormInputs(self.driver)

        self.driver.get('https://rahulshettyacademy.com/angularpractice/')
        print(f'Title of the webpage is: {self.driver.title}')
        homepage.email_input(formFillDataSet['email'])
        homepage.pass_input(formFillDataSet['password'])
        homepage.checkboxSelect()
        gender_DD = homepage.genderRadio()
        dropdown = Select(gender_DD)
        dropdown.select_by_visible_text('Female')
        dropdown.select_by_index(0)
        homepage.name_input(formFillDataSet['name'])
        homepage.name_inputClear()
        homepage.select_radio()
        homepage.submitBtn_Click()
        homepage.successAlertMsg()
        print(homepage.successAlertMsg())

        self.driver.find_element(By.XPATH, "(//input[@type='text'])[3]").send_keys(homepage.successAlertMsg())
        time.sleep(5)

        assert 'Success!' in homepage.successAlertMsg()

    @pytest.fixture(params= HomePageData.formFillDataSet1)
    def formFillDataSet(self,request):
        return request.param








