from selenium.webdriver.common.by import By


class ConfirmPurchase:

    # self.driver.find_element(By.CSS_SELECTOR, "#country").send_keys("I")
    country_inputtext = (By.CSS_SELECTOR, "#country")

    # country_list = self.driver.find_elements(By.XPATH, "//div[@class='suggestions']/ul/li/a")
    country_list =  (By.XPATH, "//div[@class='suggestions']/ul/li/a")

    # self.driver.find_element(By.LINK_TEXT, "term & Conditions").click()
    tnc_hyplink = (By.LINK_TEXT, "term & Conditions")

    # tnc_head = self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/h1").text
    tnc_head = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/h1")

    # tnc_body = self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/p").text
    tnc_body = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/p")

    # self.driver.find_element(By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/button").click()
    tnc_closebtn = (By.XPATH,"//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/button")


    # self.driver.find_element(By.XPATH, "//input[@value='Purchase']").click()
    purchase_btn = (By.XPATH, "//input[@value='Purchase']")

    # success_msg = self.driver.find_element(By.CLASS_NAME, "alert-success").text
    success_msg = (By.CLASS_NAME, "alert-success")

    def __init__(self,driver):
        self.driver = driver

    def county_inputbox(self):
        return self.driver.find_element(*ConfirmPurchase.country_inputtext)

    def countries_list(self):
        return self.driver.find_elements(*ConfirmPurchase.country_list)

    def tnc_popup(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_hyplink)

    def tnc_heading(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_head)

    def tnc_bodytext(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_body)

    def tnc_close(self):
        return self.driver.find_element(*ConfirmPurchase.tnc_closebtn)

    def purchase_click(self):
        return self.driver.find_element(*ConfirmPurchase.purchase_btn)

    def success_text(self):
        return self.driver.find_element(*ConfirmPurchase.success_msg)