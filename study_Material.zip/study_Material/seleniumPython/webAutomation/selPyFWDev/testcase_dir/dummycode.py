service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
driver = webdriver.Edge(service=service_obj,options=customOptions)

driver.get('https://rahulshettyacademy.com/angularpractice/')
print(f'Title of the webpage is: {driver.title}')

# --- Different Types Of Locators are used to identify web elements

driver.find_element(By.NAME, 'email').send_keys('testemail@xyz.com')
time.sleep(2)
driver.find_element(By.ID, 'exampleInputPassword1').send_keys('12345')
time.sleep(2)
driver.find_element(By.XPATH, "//input[@type='checkbox']").click()
time.sleep(2)


# --- Static Dropdown Selection
gender_DD = driver.find_element(By.CSS_SELECTOR, '#exampleFormControlSelect1')
dropdown = Select(gender_DD)
dropdown.select_by_visible_text('Female')
time.sleep(3)
dropdown.select_by_index(0)


driver.find_element(By.CSS_SELECTOR, "input[name='name']").send_keys('Testing123')
time.sleep(2)
driver.find_element(By.XPATH, "(//input[@type='text'])[3]").clear()
driver.find_element(By.CSS_SELECTOR, "#inlineRadio1").click() #CSS Selector using ID attribute with #
time.sleep(2)
driver.find_element(By.XPATH, "//input[@value='Submit']").click()
time.sleep(2)
success_banner = driver.find_element(By.CSS_SELECTOR, ".alert-success").text #CSS Selector using CLASS attribute with . dot
time.sleep(2)
print(success_banner)
driver.find_element(By.XPATH, "(//input[@type='text'])[3]").send_keys(success_banner)
time.sleep(2)


assert 'Success!' in success_banner






