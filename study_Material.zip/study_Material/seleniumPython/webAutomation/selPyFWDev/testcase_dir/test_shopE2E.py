import time
from selenium.webdriver.common.by import By
from utilities.Baseclass import Baseclass
from testcase_dir.page1_shop import HomePage


# @pytest.mark.usefixtures("invokeBrowser")
class Test_Scenario_DevicePurchase(Baseclass):

    def test_shopE2E(self):
        mylogger = self.LogCollector()

        shopPage_obj = HomePage(self.driver)
        # checkout_obj = CheckOut(self.driver)
        # confirmpurchase_obj = ConfirmPurchase(self.driver)

        mylogger.info('Opening Angular Home Page')
        self.driver.get('https://rahulshettyacademy.com/angularpractice/')
        mylogger.info(f'Page Title: {self.driver.title}')
        mylogger.info(f'Current URL: {self.driver.current_url}')

        # shopPage_obj.shop_click().click()  #POM
        checkout_obj = shopPage_obj.shop_click() #POM
        mylogger.info('Click on Shop Button')

        mylogger.info(f'\nPage Title: {self.driver.title}')
        mylogger.info(f'Current URL: {self.driver.current_url}\n')

        item_list = checkout_obj.item_lists() #POM
        mylogger.info('Iterating through available items')
        for value_item in item_list:
            item_name = value_item.find_element(By.XPATH, "div/h4/a").text
            mylogger.info(item_name)
            if item_name == "iphone X":
                value_item.find_element(By.XPATH, "div[2]/button").click()

        checkout_obj.checkout_initial().click() #POM

        # checkout_obj.checkout_final().click() #POM
        confirmpurchase_obj = checkout_obj.checkout_final() #POM

        confirmpurchase_obj.county_inputbox().send_keys("I") #POM

        # wait_EC = WebDriverWait(self.driver, 10)
        # wait_EC.until(expected_conditions.presence_of_element_located((By.CSS_SELECTOR, ".suggestions")))
        mylogger.info('Waiting for all suggestions to load')
        self.explicitWaitElementPresence(".suggestions")

        confirmpurchase_obj.countries_list() #POM

        for value_country in confirmpurchase_obj.countries_list():
            mylogger.info(value_country.text)

            if value_country.text == 'India':
                value_country.click()
                break

        confirmpurchase_obj.tnc_popup().click() #POM
        time.sleep(1)
        tnc_head = confirmpurchase_obj.tnc_heading().text  #POM
        time.sleep(1)
        tnc_body = confirmpurchase_obj.tnc_bodytext().text  #POM

        mylogger.info(f"{tnc_head}:\n{tnc_body}")
        confirmpurchase_obj.tnc_close().click()


        confirmpurchase_obj.purchase_click().click() #POM
        success_msg = confirmpurchase_obj.success_text().text #POM

        mylogger.info('Final Message is : '+success_msg)
        assert "Success! Thank you!" in success_msg

