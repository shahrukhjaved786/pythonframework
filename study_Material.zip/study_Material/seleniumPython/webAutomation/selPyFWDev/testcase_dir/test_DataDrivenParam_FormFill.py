import time
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from testcase_dir.page1_Form import FormInputs
from utilities.Baseclass import Baseclass_FixCallL


class TestHomePageAngular(Baseclass_FixCallL):

    def test_FormSubmission(self, formFillDataSets):

        homepage = FormInputs(self.driver)

        self.driver.get('https://rahulshettyacademy.com/angularpractice/')
        print(f'Title of the webpage is: {self.driver.title}')
        homepage.email_input(formFillDataSets[0])
        homepage.pass_input(formFillDataSets[1])
        homepage.checkboxSelect()
        gender_DD = homepage.genderRadio()
        dropdown = Select(gender_DD)
        dropdown.select_by_visible_text('Female')
        dropdown.select_by_index(0)
        homepage.name_input(formFillDataSets[2])
        homepage.name_inputClear()
        homepage.select_radio()
        homepage.submitBtn_Click()
        homepage.successAlertMsg()
        print(homepage.successAlertMsg())

        self.driver.find_element(By.XPATH, "(//input[@type='text'])[3]").send_keys(homepage.successAlertMsg())
        time.sleep(2)

        assert 'Success!' in homepage.successAlertMsg()
        time.sleep(15)


#Since the below data sets is particular to only this testcase, due to this reason its not written under conftest.py
#Fixture to run the testcase with multiple data sets at runtime

    @pytest.fixture(params=[('testemail@xyz.com',"pass@123","Rahul"),("randomemail@xyz.com","password12345","Jimmy S"),("hello123@yah.com",'pw123456789','Tim C')])
    def formFillDataSets(self,request):
        return request.param



