from selenium.webdriver.common.by import By
from testcase_dir.page2_checkout import CheckOut


class HomePage:

    def __init__(self,driver):
        self.driver = driver

    '''
    convert the above web element locator to POM
    # self.driver.find_element(By.XPATH, "//a[contains(@href,'shop')]").click()
    '''

    shop_btn = (By.XPATH, "//a[contains(@href,'shop')]")
    def shop_click(self):
        self.driver.find_element(*HomePage.shop_btn).click()
        checkout_obj = CheckOut(self.driver)
        return checkout_obj

