
import openpyxl

book = openpyxl.load_workbook(filename="/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/oPyXL/BookTestOPE.xlsx")
sheet = book.active

print('------------')
#print data from specific Cell
cell_A1 = sheet.cell(row=1, column=1)
print(cell_A1.value)

cell_B1 = sheet.cell(row=1,column=2)
print(cell_B1.value)

print('------------')
#shortcut way to directly get value from Cell
cell_C3 = sheet["C3"].value
print(cell_C3)

print('------------')
#print the total number of Rows & Column in sheet
print(sheet.max_row)
print(sheet.max_column)

print('------------')
#print all the Column-1 value present in active sheet
for value_col in range(1,sheet.max_row+1):
    print(sheet.cell(row=value_col,column=1).value)

print('------------')
#print all the Row-1 value present in active sheet
for value_row in range(1,sheet.max_column+1):
    print(sheet.cell(row=1,column=value_row).value)

print('------------')
#print all the values present in active sheet
for value_i in range(1,sheet.max_row+1):
    print() #blank line
    for value_j in range(1,sheet.max_column+1):
        print(sheet.cell(row=value_i,column=value_j).value)

print('------------')
#print only data for TC3 i.e row 4 data from coulmn 2 till end
for value_i in range(1,sheet.max_row+1):
    if sheet.cell(row=value_i, column=1).value == "TC3":
        for value_j in range(2,sheet.max_column+1):
            print(sheet.cell(row=value_i, column=value_j).value)

#get data from excel sheet in dictionary to pass on at the runtime

mydict = {}
# {'fistname':Rahul,'Lastname':'spakrs',"gender":'male'}
for value_i in range(1,sheet.max_row+1):
    if sheet.cell(row=value_i,column=1).value == 'TC1':
        for value_j in range(2,sheet.max_column+1):
            mydict[sheet.cell(row=1, column=value_j).value] = sheet.cell(row=value_i, column=value_j).value
print(mydict)

# print all entries
for value_i in range(2,sheet.max_row+1):
    for value_j in range(2,sheet.max_column+1):
        mydict[sheet.cell(row=1, column=value_j).value] = sheet.cell(row=value_i, column=value_j).value
    print(mydict)


