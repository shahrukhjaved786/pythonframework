# import openpyxl
#
#
#
# def getDataForARow(testName):
#     book = openpyxl.load_workbook('BookTestOPE.xlsx')
#     sheet = book.active
#     maxRow = sheet.max_row
#     maxCol = sheet.max_column
#     data = []
#     Dict = {}
#     for r in range(1, maxRow + 1):
#         if testName in sheet.cell(row=r, column=1).value:
#             for c in range(2, maxCol + 1):
#                 Dict[sheet.cell(row=1, column=c).value] = sheet.cell(row=r, column=c).value
#             data.append(Dict.copy())
#     # return data
#     print(data)
#
# getDataForARow("FormSubmission")


import openpyxl


class Test_DDP:
    @staticmethod
    def getUserInfo(testcase_id):

        data_dict = {}
        userDataList = []

        book = openpyxl.load_workbook(
            "/Users/shahrukhj/Documents/study_Material/seleniumPython/webAutomation/oPyXL/BookTestOPE.xlsx")
        sheet = book.active

        for value_i in range(1, sheet.max_row + 1):
            if testcase_id in sheet.cell(row=value_i, column=1).value:
                for value_j in range(1, sheet.max_column + 1):
                    data_dict[sheet.cell(row=1, column=value_j).value] = sheet.cell(row=value_i, column=value_j).value
                userDataList.append(data_dict.copy())

        # return userDataList
        print(userDataList)
        print(len(userDataList))


Test_DDP.getUserInfo('FormSubmission')