# Visit URL > https://rahulshettyacademy.com/seleniumPractise
# Click on top deals.
# Grab all the items name.
# Pass these items name into a list and sort the list with a variable name expected list
# Click on header to sort the table
# Grab all the items name again
# Grab the name of all the items from the table and store these as actual list
# Now compare the actual list with expected list
import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service
from selenium.webdriver.support.select import Select

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)

driver.get('https://rahulshettyacademy.com/seleniumPractise')
print(f"\nPage Title: {driver.title}")
print(f"\nCurrent URL: {driver.current_url}")

driver.find_element(By.LINK_TEXT, "Top Deals").click()
time.sleep(2)
window_title = driver.window_handles
driver.switch_to.window(window_title[1]) #switching focus to child window

print(f"\nChild Page Title: {driver.title}")
print(f"\nChild URL: {driver.current_url}")
assert driver.current_url == "https://rahulshettyacademy.com/seleniumPractise/#/offers"

pagesize_dropdown_obj = Select(driver.find_element(By.CSS_SELECTOR, "#page-menu"))

# web_element -> <select><option value="20">20</option></select>
# pagesize_dropdown_obj.select_by_visible_text("20") # --> This is referred for visible text ">20<"
# pagesize_dropdown_obj.select_by_value("20") #-> value="20"
pagesize_dropdown_obj.select_by_index(2) # index position starting from 0 of 5,1 for 10 and 2 for 20

time.sleep(1)
driver.get_screenshot_as_file("Default_List.png")

items_default_list = driver.find_elements(By.XPATH, "//tr/td[1]")
default_list =[]

for item1 in items_default_list:
    default_list.append(item1.text)
time.sleep(2)
print(f'\nDefault List: {default_list}')
expected_sorted_list = sorted(default_list)
print(f"\nSorted List: {expected_sorted_list}")

driver.find_element(By.XPATH, "//span[text()='Veg/fruit name']").click()
time.sleep(2)
driver.get_screenshot_as_file("Sorted_By_Header.png")

item_after_click = driver.find_elements(By.XPATH, "//tbody/tr/td[1]")

list_after_click = []
for item2 in item_after_click:
    list_after_click.append(item2.text)


print(f"\nList After Header Click {list_after_click}")
assert list_after_click == expected_sorted_list

driver.close()
time.sleep(2)
driver.switch_to.window(window_title[0])

parent_footer_text = driver.find_element(By.XPATH, '//footer/p').text
print(f'\nSwitched Back To Parent WebPage: {driver.title}, {parent_footer_text}')

time.sleep(2)