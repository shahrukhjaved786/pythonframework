import time

from selenium import webdriver
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
customOptions.add_experimental_option("excludeSwitches",['enable-automation'])


driver = webdriver.Edge(service=service_obj,options=customOptions)
time.sleep(2)
driver.get("https://www.google.com")

time.sleep(5)