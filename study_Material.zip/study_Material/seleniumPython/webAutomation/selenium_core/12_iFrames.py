import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
# customOptions.add_argument('--headless')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(2)


driver.get("https://the-internet.herokuapp.com/iframe")
print(f"Page Title: {driver.title}")
print(f'Current URL: {driver.current_url}')

'''
Switching browser scope to Frame level
'''
driver.switch_to.frame('mce_0_ifr') #passed the ID of the TOP LEVEL FRAME, NAME can also be passed


frame_body_text = driver.find_element(By.TAG_NAME, "p").text
print(frame_body_text)
time.sleep(1)
driver.find_element(By.TAG_NAME, "p").clear()
print('Cleared the data from frame')
time.sleep(1)
driver.find_element(By.TAG_NAME, "p").send_keys('Hello,\nThis is the new data sent into frame body')
print("Newly Inserted Input Is: ",frame_body_text)
time.sleep(1)
'''
Switching browser scope back to default browser level from Frame
'''

driver.switch_to.default_content()
print(f'Browser Level Heading:\n{driver.find_element(By.TAG_NAME, "h3").text}')
time.sleep(2)