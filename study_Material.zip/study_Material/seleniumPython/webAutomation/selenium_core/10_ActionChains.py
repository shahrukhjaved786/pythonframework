import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
# customOptions.add_argument('--headless')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)
action_C = ActionChains(driver)

driver.get('https://rahulshettyacademy.com/AutomationPractice/')

print(f'Page Title: {driver.title}')
print(f"Current URL : {driver.current_url}")

action_C.move_to_element(driver.find_element(By.CSS_SELECTOR, "#mousehover")).perform()
time.sleep(1) #for functionality visibility
action_C.context_click(driver.find_element(By.LINK_TEXT, "Top")).perform()
time.sleep(1) #for functionality visibility
action_C.move_to_element(driver.find_element(By.CSS_SELECTOR, "#mousehover")).click().perform()
time.sleep(1) #for functionality visibility
action_C.move_to_element(driver.find_element(By.CSS_SELECTOR, "#mousehover")).perform()
time.sleep(1) #for functionality visibility
action_C.move_to_element(driver.find_element(By.LINK_TEXT, "Reload")).click().perform()