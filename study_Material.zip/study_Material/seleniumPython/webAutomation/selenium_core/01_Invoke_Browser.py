import time
from selenium import webdriver
from selenium.webdriver.edge.service import Service

from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.safari.options import Options as SafariOptions

service_obj = Service() #serive method will automatically download the compatible drvier as per browser verison

# --- For MICROSOFT EDGE Browser
customOptions =EdgeOptions()
customOptions.add_argument('inprivate')

# --- Turn Off The Ribon Chrome / Micrsoft Edge is being controller by automation software
customOptions.add_experimental_option('excludeSwitches', "[enable-automation]")

driver = webdriver.Edge(service=service_obj,options=customOptions) #driver is object of the browser


# --- For CHROME Browser
# customOptions = ChromeOptions()
# customOptions.add_argument('incognito')
# driver = webdriver.Chrome(service=service_obj,options=customOptions)

# --- For Safari Browser
# customOptions = SafariOptions()
# customOptions.add_argument('inprivate')
# driver = webdriver.Safari(service=service_obj,options=customOptions)


driver.get('https://www.google.com')
print('Visit: Google.com')
print(driver.title)
print(driver.current_url)
driver.maximize_window()

driver.get("https://rahulshettyacademy.com")
print('Visit: RSA')
driver.refresh()
print(driver.title)
print(driver.current_url)

driver.back()
driver.minimize_window()
print('Back To: Google')
print(driver.title)

driver.forward()
print('Forward To: RSA')
print(driver.title)

time.sleep(10)
driver.close()
