import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj,options=customOptions)

driver.get('https://rahulshettyacademy.com/AutomationPractice/')
print(f'Page Title : {driver.title}')
print(f"Current URL: {driver.current_url}")


# --- Handling Dynamic Checkboxes using find_elements
checkbox_options = driver.find_elements(By.XPATH, "//input[@type='checkbox']")
time.sleep(2)
for value_cb in checkbox_options:
    if value_cb.get_attribute('value') == 'option2':
        value_cb.click()

        print(f"Selected Checkbox is: {value_cb.get_attribute('value')}")

        assert value_cb.is_selected()

        break
else:
    print('Attribute Match Not Found')


# --- Handling Dynamic Checkboxes using find_elements & get attributes
radioButtons = driver.find_elements(By.CSS_SELECTOR, "input[class='radioButton']")

for value_rb in radioButtons:
    if value_rb.get_attribute('value') == 'radio3':
        value_rb.click()
        print(f"Selected Radio Button Is: {value_rb.get_attribute('value')}")
        assert value_rb.is_selected()

        break
else:
    print('Attribute Match Not Found')

# --- Handling web element displayed or not on UI
assert driver.find_element(By.ID, "displayed-text").is_displayed()
time.sleep(2)
driver.find_element(By.CSS_SELECTOR, "#hide-textbox").click()
time.sleep(2)
assert not driver.find_element(By.ID, "displayed-text").is_displayed() #assert NOT will verify if return result is false or not
time.sleep(3)

