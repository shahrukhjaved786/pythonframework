import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj, options=customOptions)

driver.get('https://rahulshettyacademy.com/dropdownsPractise/')
print(f'Page Title: {driver.title}')
print(f'Current URL: {driver.current_url}')
time.sleep(2)

driver.find_element(By.CSS_SELECTOR, "#autosuggest").send_keys('ind')
time.sleep(3)

# --- find_elements() -- Returns a LIST

country_list = driver.find_elements(By.XPATH, "//li[@class='ui-menu-item']/a")

for value_country in country_list:
    if value_country.text == "India":
        value_country.click()
        break

time.sleep(2)
print('Dropdown Selected Value is: ',driver.find_element(By.ID, "autosuggest").get_attribute('value'))
assert driver.find_element(By.ID, "autosuggest").get_attribute("value") == "India"

