import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)
wait_exp = WebDriverWait(driver, 10)


'''
- Implicit  wait is the global timeout of the script.
- Implicit wait will not catch the find_elementS because it will check the output returned inside the list, 
- It will just check what is the return type of find elements that will be a list, 
- and if list is returned even if an empty list it will proceed ahead.
'''


driver.get('https://rahulshettyacademy.com/seleniumPractise/#/')

search_keyword = 'ber'

driver.find_element(By.CSS_SELECTOR, ".search-keyword").send_keys(search_keyword)
# time.sleep(3)

driver.find_element(By.CLASS_NAME, "search-button").click()

item_list = driver.find_elements(By.XPATH, "//div[@class='product']")
count = len(item_list)
print(f'Number Of Items Listed: {count}')
assert count > 0

for product in item_list:
    item_name = product.find_element(By.TAG_NAME,"h4").text

    '''
    overall xpath of full product card is : "//div[@class='product']"
    and the button xpath is /div/button
    
    BUT when we chain child XPATH i.e button with PARENT i.e product card then we DO NOT ADD the first forward slash
    i.e only mention the div/button NOT the /div/button
    '''
    product.find_element(By.XPATH, "div/button").click()
    # time.sleep(1)
    print(item_name)

driver.find_element(By.XPATH, "//img[@alt='Cart']").click()
driver.find_element(By.XPATH, "//button[text()='PROCEED TO CHECKOUT']").click()

wait_exp.until(expected_conditions.presence_of_element_located((By.CLASS_NAME, "promoCode")))
'''
web element path should be passed under BRACES like this in (By.CLASS_NAME, "promoCode")
'''

valid_promo_code = 'rahulshettyacademy'
invalid_promo_code = 'rsa'
# time.sleep(2)

driver.find_element(By.CSS_SELECTOR, ".promoCode").send_keys(valid_promo_code)
driver.find_element(By.CLASS_NAME, "promoBtn").click()
# time.sleep(6)

wait_exp.until(expected_conditions.presence_of_element_located((By.CLASS_NAME, "promoInfo")))


code_success = driver.find_element(By.CSS_SELECTOR, ".promoInfo").text
assert "Code applied ..!" == code_success
print(code_success)

