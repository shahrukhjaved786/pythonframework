import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj,options=customOptions)


driver.get('https://rahulshettyacademy.com/client/')
print(f'Page Title: {driver.title}')
print(f'Current Page URL: {driver.current_url}')
time.sleep(2)
driver.find_element(By.LINK_TEXT, "Forgot password?").click()
time.sleep(2)
driver.find_element(By.XPATH, "//form/div[1]/input").send_keys('demo@gmail.com') #Parent To Chile Traversing using tags
time.sleep(2)
driver.find_element(By.CSS_SELECTOR, "form div:nth-child(2) input").send_keys('He@1234')
time.sleep(2)
driver.find_element(By.XPATH, "//input[@formcontrolname='confirmPassword']").send_keys("He@1234")
time.sleep(2)
driver.find_element(By.XPATH, "//button[text()='Save New Password']")
time.sleep(2)
