import time

from selenium import webdriver
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
customOptions.add_argument('ignore-certificate-errors')
# customOptions.add_argument('--headless')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)

driver.get('https://rahulshettyacademy.com/AutomationPractice/')
print(f"Page Title: {driver.title}")
print(f"Current URL: {driver.current_url}")
time.sleep(1)
driver.execute_script("window.scrollBy(0,500);")

driver.get_screenshot_as_file(driver.title+".png")
time.sleep(2)
driver.execute_script("window.scrollBy(0,document.body.scrollHeight);")
driver.get_screenshot_as_file("LastPage.png")