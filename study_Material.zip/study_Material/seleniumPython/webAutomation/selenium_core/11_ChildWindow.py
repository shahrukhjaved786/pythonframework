import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
# customOptions.add_argument('--headless')

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)


driver.get('https://the-internet.herokuapp.com/windows')
print(f"Page Title: {driver.title}")
print(f"Current URL: {driver.current_url}")

parent_window_text = driver.find_element(By.TAG_NAME, "h3").text
print("Printing From Parent Window:", parent_window_text)
time.sleep(2)
driver.find_element(By.LINK_TEXT, "Click Here").click()
time.sleep(2)

'''
Important point to note that declare the "driver.window" property right before using it. 
If in general, we declare it at the beginning then while calling it, it won't function as expected.
'''
window_title = driver.window_handles

driver.switch_to.window(window_title[1]) # Focused  to Child Window --> window_title[1]
time.sleep(2)
child_window_text = driver.find_element(By.TAG_NAME, "h3").text
print("Printing From Child Window:", child_window_text)
time.sleep(2)
driver.close() #closing child window

driver.switch_to.window(window_title[0]) # Focus Back to Parent Window --> Window_title[0]
time.sleep(2)
parent_window_text2 = driver.find_element(By.XPATH, "//div[@style='text-align: center;']").text
print("Switched Back To Parent Window", parent_window_text2)

time.sleep(3)