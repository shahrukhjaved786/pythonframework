import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')

driver = webdriver.Edge(service=service_obj,options=customOptions)

driver.get('https://rahulshettyacademy.com/AutomationPractice/')
print(f'Page Tile: {driver.title}')
print(f'Current URL: {driver.current_url}')

test_keyword = 'Test Man'
driver.find_element(By.CSS_SELECTOR, "#name").send_keys(test_keyword)
time.sleep(2)
driver.find_element(By.XPATH, "//input[@class='btn-style']").click()

# ---> Switch to ALERT MODE to handle Java Alerts
alert_obj = driver.switch_to.alert
alert_message = alert_obj.text
print(alert_message)
assert test_keyword in alert_message
time.sleep(2)
alert_obj.accept()
time.sleep(3)