# EXPECTED OUTPUT
# Page Title : GreenKart - veg and fruits kart
# Current URL: https://rahulshettyacademy.com/seleniumPractise/#/
# Actual List is:
#  ['Cucumber - 1 Kg', 'Raspberry - 1/4 Kg', 'Strawberry - 1/4 Kg']
# Expected List is:
#  ['Cucumber - 1 Kg', 'Raspberry - 1/4 Kg', 'Strawberry - 1/4 Kg']
# Cart Sum:  388
# Total Amount:  388
# Cart Total Amount Is: 388
# Discount :  349
# Amount After 10% Discount: 349


import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
customOptions.add_argument("--headless")

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.implicitly_wait(3)
wait_exp = WebDriverWait(driver,10)


driver.get('https://rahulshettyacademy.com/seleniumPractise/#/')
print(f'Page Title : {driver.title}')
print(f'Current URL: {driver.current_url}')

search_keyword = 'ber'
expected_item_list = ["Cucumber - 1 Kg","Raspberry - 1/4 Kg","Strawberry - 1/4 Kg"]
actual_item_list = []
cart_sum = 0
promo_code = 'rahulshettyacademy'

driver.find_element(By.CSS_SELECTOR, ".search-keyword").send_keys(search_keyword)
time.sleep(2)
driver.find_element(By.CLASS_NAME, "search-button").click()

item_lists = driver.find_elements(By.XPATH, "//div[@class='products']/div")

for value_item in item_lists:
    value_item.find_element(By.XPATH, "div[3]/button").click()
    item_name = value_item.find_element(By.TAG_NAME, "h4").text
    actual_item_list.append(item_name)

print(f"Actual List is: \n {actual_item_list}")
print(f"Expected List is: \n {expected_item_list}")

assert actual_item_list == expected_item_list

driver.find_element(By.XPATH, "//img[@alt='Cart']").click()
driver.find_element(By.XPATH, "//button[text()='PROCEED TO CHECKOUT']").click()

# driver.find_element(By.CSS_SELECTOR, "tr td:nth-child(5) p")

cart_total_value = driver.find_elements(By.XPATH, "//tr/td[5]/p")

for value_item in cart_total_value:
    cart_sum = cart_sum + int(value_item.text)


total_amount = int(driver.find_element(By.CLASS_NAME, "totAmt").text)

print("Cart Sum: ", cart_sum)
print("Total Amount: ", total_amount)
assert cart_sum == int(total_amount)

driver.find_element(By.CSS_SELECTOR, ".promoCode").send_keys(promo_code)
driver.find_element(By.CLASS_NAME, "promoBtn").click()

wait_exp.until(expected_conditions.presence_of_element_located((By.CLASS_NAME, "promoInfo")))

promo_msg = driver.find_element(By.CSS_SELECTOR, ".promoInfo").text
assert promo_msg == "Code applied ..!"

disc_amt = float(driver.find_element(By.CSS_SELECTOR, ".discountAmt").text)

disc_amt_10p = int(total_amount) - (int(total_amount)/10)

print("Cart Total Amount Is:", int(total_amount))
print("Discount : ", int(disc_amt_10p))
print("Amount After 10% Discount:", int(disc_amt))

'''
Ignored Decimal place variance to avoid mathematical errors 
'''

assert int(total_amount) > int(disc_amt) #validating discount is applied
assert int(disc_amt_10p) == int(disc_amt) #validating exactly 10% discount is applied

