import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait


user_brand = input('Enter Brand Name: [Nokia Edge, Samsung Note 8, iphone X,Blackberry]\n')
start_time = time.time()

service_obj = Service()
customOptions = EdgeOptions()
customOptions.add_argument('inprivate')
customOptions.add_argument('start-maximized')
customOptions.add_argument('--disable-gpu')

customOptions.add_argument('--headless')
# customOptions.add_experimental_option('excludeSwitches', "[enable-automation]")

driver = webdriver.Edge(service=service_obj,options=customOptions)
driver.get('https://rahulshettyacademy.com/angularpractice/')
print(f'Page Title: {driver.title}')
print(f'Current URL: {driver.current_url}')

#Regular Expression Custom XPATH For Web Element
driver.find_element(By.XPATH, "//a[contains(@href,'shop')]").click()
# time.sleep(1)

#Custom CSS Locator
# driver.find_element(By.CSS_SELECTOR, "a[href*='shop']").click()

print(f'\nPage Title: {driver.title}')
print(f'Current URL: {driver.current_url}\n')

item_list = driver.find_elements(By.XPATH, "//div[@class='card h-100']")

item_name_list = []
for value_item in item_list:
    item_name = value_item.find_element(By.XPATH, "div/h4/a").text
    print(item_name)
    if item_name == user_brand:
        value_item.find_element(By.XPATH, "div[2]/button").click()
# time.sleep(2)

driver.find_element(By.PARTIAL_LINK_TEXT, "Checkout").click()
# time.sleep(3)


driver.find_element(By.XPATH, "//button[@class='btn btn-success']").click()
driver.find_element(By.CSS_SELECTOR, "#country").send_keys("I")

wait_EC = WebDriverWait(driver,10)
wait_EC.until(expected_conditions.presence_of_element_located((By.CSS_SELECTOR, ".suggestions")))

country_list = driver.find_elements(By.XPATH, "//div[@class='suggestions']/ul/li/a")

for value_country in country_list:
    print(value_country.text)

    if value_country.text == 'India':
        value_country.click()
        break

# time.sleep(2)

driver.find_element(By.LINK_TEXT, "term & Conditions").click()
time.sleep(1)
tnc_head = driver.find_element(By.XPATH, "//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/h1").text
time.sleep(1)
tnc_body = driver.find_element(By.XPATH, "//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/p").text

print(f"{tnc_head}:\n{tnc_body}")


driver.find_element(By.XPATH, "//div[@class='nsm-dialog-animation-fade nsm-dialog nsm-dialog-open']/button").click()

driver.find_element(By.XPATH, "//input[@value='Purchase']").click()
# time.sleep(2)
success_msg = driver.find_element(By.CLASS_NAME, "alert-success").text
print(success_msg)
assert "Success! Thank you!" in success_msg

end_time = time.time()
execution_time = end_time - start_time

start_time = time.ctime(start_time)
end_time = time.ctime(end_time)
print(f"Start Time: {start_time}\nEnd Time: {end_time}\nTotal Execution Duration: {execution_time}")