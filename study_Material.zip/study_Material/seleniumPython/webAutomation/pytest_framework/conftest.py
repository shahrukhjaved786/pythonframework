import pytest


@pytest.fixture()
def setup():
    print('I will be executed first')
    print('Running Preconditions before executing methods')

    yield
    print('Running POST condition after completion of methods')


@pytest.fixture(scope='class')
def setup_paypal():
    print('Executing PP Precondition')

    yield
    print('Executing PP Postconditions')


@pytest.fixture()
def user_profile_data():
    return ['Olga','Alferova',"o.alf@fm.com"]


@pytest.fixture(params=['Chrome','Edge','IE','Safari'])
def crossBrowser(request):
    return request.param


@pytest.fixture(params=[
    ('Chrome','Chris U','rlqa122'),
    ('Edge','Inna R','EM123'),
    ('IE','Charleen A','sup123'),
    ('Safari','Umed A','otc123')])
def crossBrowserLogin(request):
    return request.param


@pytest.fixture()
def candidatedata():
    return ['Mark','Olsen','m.olsen@abc.com']




