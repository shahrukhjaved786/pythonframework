import logging


def test_LoggerCollector():
    logger_obj = logging.getLogger(__name__)

    fileHandler_obj = logging.FileHandler('pytest_logs.log')

    default_logging_syntax = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
    fileHandler_obj.setFormatter(default_logging_syntax)

    logger_obj.addHandler(fileHandler_obj)

    logger_obj.setLevel(logging.DEBUG)

    logger_obj.debug('Executing Debug Level Message')
    logger_obj.info("Information Statement")
    logger_obj.warning('Some condition in warning level')
    logger_obj.error('Error while executing method')
    logger_obj.critical('Critical Error')


'''
Steps:

1. import logging
2. use logging.getLogger() method and pass the __name__ [to grab the exact pytest file name]
3. define the logging messages such as [ logger_obj.critical('Critical Error') ]
4. Give information about in which file logs has to be printed by using addHandler & FileHandler method
    filehandler_obj = logging.FileHandler('pytest_logfile.txt') [pass the default logs path]
    logger_obj = logging.addHandler(filehandler_obj)

5. Now give the information in which format to print logs
    default_log_format = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
    fileHandler.setFormatter(default_log_format)

6. At Last set the level from which level onwards logs has to be printed
    logger_obj.setLevel(logging.INFO)
    

'''
