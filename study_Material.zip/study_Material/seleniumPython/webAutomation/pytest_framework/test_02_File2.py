import pytest


@pytest.mark.smoke
def test_ThirdProgram():
    print("great work")

@pytest.mark.sanity
def test_Fourth_addition(setup):
    a =4
    b = 6
    assert a+2 == b, "Addition did not match to value"
    print('I am running with CONFTEST.py FIXTURE SETUP')

@pytest.mark.OSregression
@pytest.mark.skip
def test_Fifth_Subs():
    c = 10
    d = 4
    assert c - d == c + d , "Subtracted value did not match"