import pytest


@pytest.mark.usefixtures("user_profile_data")
class Test_Scenario3:
    def test_userprofile(self,user_profile_data):
        print(user_profile_data)

        print(f"User name: {user_profile_data[0]} {user_profile_data[1]}")
        print(f"Email: {user_profile_data[2]}")