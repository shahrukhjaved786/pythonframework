import pytest

'''
Independent fixture set up when conftest.py file is NOT defined.
'''

# @pytest.fixture()
# def setup():
#     print('I Will Be Executed First')
#     print("Preconditions from the fixture setup")
#     yield
#     print("POST condition execution after completion of method execution")
#
#
# def test_fixtureDemo1(setup):
#     print('I Will Execute Steps In Fixture Demo Method')