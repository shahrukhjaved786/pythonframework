import pytest


@pytest.mark.usefixtures("setup")
class Test_Scenario1:

    def test_CC_Number(self):
        print('Card Number : 4111 xxxx xxxx 0000')

    def test_CC_Cvv(self):
        print('CVV : 123')

    def test_CC_Expiry(self):
        print('Expiry : 11/12/2099')

    def test_CC_Zipcode(self):
        print('Postcode : 50001')


@pytest.mark.usefixtures('setup_paypal')
class Test_Scenario2:

    def test_PayPal_Email1(self):
        print('PayPal Email_1 : js.0077@abc.com')

    def test_PayPal_Passcode1(self):
        print('PayPal Passcode_1 : abc@123')

    def test_PayPal_Email2(self):
        print('PayPal Email_2 : po.0077@xyz.com')

    def test_PayPal_Passcode2(self):
        print('PayPal Passcode_2 : xyz@123')
