import pytest

from pytest_framework.Logger_BaseClass import Log_BaseClass


@pytest.mark.usefixtures("crossBrowser")
class Test_Scenario4:
    def test_multiplatform(self,crossBrowser):
        print(crossBrowser)


def test_4platform(crossBrowser):
    print(crossBrowser)


def test_4platLogin(crossBrowserLogin):
    print(f'Browser: {crossBrowserLogin[0]},Username: {crossBrowserLogin[1]} and passkey: {crossBrowserLogin[1]}')

