import inspect
import logging


class Log_BaseClass:
    def LogCollector(self):

        loggerMethodName = inspect.stack()[1][3]  # to add the actual method name in logs file from where this logger basecloss is being called
        #logger_obj = logging.getLogger(__name__)
        logger_obj = logging.getLogger(loggerMethodName)

        fileHandler_obj = logging.FileHandler('pytest_logs.log') #log file path

        default_logging_syntax = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
        fileHandler_obj.setFormatter(default_logging_syntax)

        logger_obj.addHandler(fileHandler_obj)

        logger_obj.setLevel(logging.DEBUG)

        return logger_obj
