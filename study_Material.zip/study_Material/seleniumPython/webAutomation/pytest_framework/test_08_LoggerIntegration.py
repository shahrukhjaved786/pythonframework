import pytest
from pytest_framework.Logger_BaseClass import Log_BaseClass

@pytest.mark.usefixtures("candidatedata")
class Test_Scenario5(Log_BaseClass):
    def test_candidateprofile(self,candidatedata):

        logs = self.LogCollector()

        logs.info(candidatedata[0])
        logs.info(candidatedata[1])
        logs.info(candidatedata[2])
        logs.debug('some backend information for debugging')


'''
Logger Base Class Integration With Pytest Method wrapped in class

STEPs:

1. Have a pytest method for a testcase wrapped in a class in which data is getting loaded from the fixture
2. At the class level inherit the logger base class [as parent] into the pytest class [child class]
3. call the actual log method with self keyword [self.MethodName()] and store in new vairable
4. use the variable to access the level [ log.info / log.debug / log.warning ] and pass the message into that [fixture data or "normal string"]



'''