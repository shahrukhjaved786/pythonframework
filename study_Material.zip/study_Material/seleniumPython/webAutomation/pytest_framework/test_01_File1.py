import pytest

@pytest.mark.smoke
def test_FirstProgram():
    print('hello, this is my first program in PyTest standards')

@pytest.mark.OSregression
def test_SecondProgram():
    print('I am 2nd method')

@pytest.mark.smoke
def test_PrintCode():
    print('I am smoke scenario')


@pytest.mark.xfail
def test_precondition():
    test = 'I am precondition'
    assert test + 2 == 5 , "Addition of string with int causing the failure"


@pytest.mark.smoke
def test_dependantcase():
    print('I am dependant case')